# Public launch text / 公开发布文案

## 中文

**局部有序，不等于全局正值。**

OMEGATAO-87是一套离线优先的开放研究运行时，用于区分热力学熵、信息熵、语义不确定性和规范负担，追踪AI或组织获得局部秩序时向哪些生命世界输出了热、污染、注意损失、失能、风险和未来选择损失。

它不宣称证明宇宙总熵下降，也不宣称已经发现不可质疑的天道。它提出一个可以被现实反证的工作不动点：不可避免的耗散，应尽可能转化为真相、能力、修复、互惠和未来选择；系统自身不得例外。

仓库承诺：

> No entropy-domain laundering. No value before world effect. No system self-exemption.
>
> 不混洗熵域；不在世界效果前宣称价值；系统没有自我例外。

## English

**Local order is not global value.**

OMEGATAO-87 is an offline-first open research runtime that separates thermodynamic entropy, information entropy, semantic-uncertainty proxies and normative burden. It traces which life-worlds bear heat, pollution, attention loss, capability erosion, risk and future-option loss when an AI or institution creates local order.

It does not claim to prove global entropy decrease or reveal an unquestionable cosmic law. It tests a falsifiable working fixed point: unavoidable dissipation should be converted into truth access, capability, repair, reciprocity and future options without system self-exemption.
