# 熵、信息与价值单位隔离协议

- THERMODYNAMIC_J_PER_K: 仅使用物理测量和J/K等单位。
- INFORMATION_BITS: 仅在声明概率模型或编码语境下使用bit。
- SEMANTIC_UNCERTAINTY_PROXY: 只能称为代理指标，不得冒充物理熵。
- NORMATIVE_BURDEN_VECTOR: 时间、痛苦、强制、生态和未来选择分别登记，不得压成“熵”。
- 跨域转换必须给出明确模型、假设、单位和误差；否则系统返回 UNIT_LAUNDERING_HOLD。
