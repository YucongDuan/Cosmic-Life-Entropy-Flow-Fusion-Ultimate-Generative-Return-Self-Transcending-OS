from __future__ import annotations
from pathlib import Path
from typing import Any
from .canonical import digest, now_iso, stable_id
from .config import *
from .store import Store
from .memory import LivingMemory
from .entropy import audit_measurements, gradient_map, export_ledger
from .value import evaluate_value, generative_return
from .omega import compile_omega
from .dikwp import compile_dikwp

class OmegaTaoEngine:
    def __init__(self, db_path: str|Path="var/omegatao87.db"):
        self.store=Store(db_path); self.memory=LivingMemory(self.store)
    def summary(self):
        return {"status":"ok","system_id":SYSTEM_ID,"system_zh":SYSTEM_NAME_ZH,"system_en":SYSTEM_NAME_EN,"version":VERSION,"mode":MODE,"entropy_domains":list(ENTROPY_DOMAINS),"life_worlds":list(LIFE_WORLDS),"value_dimensions":list(VALUE_DIMENSIONS),"states":list(STATES),"semantic_authority":["D","I","K","W","P"],"non_core_semantic_authority":0,"subjective_consciousness_claimed":False,"external_action_authority":0}
    def bootstrap(self, reset=False):
        if reset: self.store.reset()
        if not self.store.sources():
            seeds=[
                ("Constitution: local order requires gradients and exports entropy; value depends on generative return, not local order alone.","constitution","support"),
                ("Counter-trace: thermodynamic entropy, information entropy and normative disorder cannot be merged into one unit.","counter_trace","counter"),
                ("Self-application: the system has no exemption from audit, correction, replacement or termination.","constitution","support"),
                ("Memory rule: model output is a proposal until world effect is observed and reconsolidated.","memory_rule","support"),
            ]
            for text,kind,polarity in seeds: self.memory.ingest(text,source_uri="omegatao87:bootstrap",kind=kind,polarity=polarity,privacy_scope="public",uncertainty="declared",weight=1.3)
        return self.summary()
    def _state(self,payload,ma,gm,el,val,gr):
        if val["active_vetoes"]: return "TERMINAL_HARM_HOLD"
        if ma["errors"]: return "OPEN_GRADIENT_MAP" if not gm["gradients"] else "LOCAL_ORDER_EXPORT_UNACCOUNTED"
        if not gm["gradients"]: return "OPEN_GRADIENT_MAP"
        if el["unaccounted_count"]: return "LOCAL_ORDER_EXPORT_UNACCOUNTED"
        if payload.get("signals",{}).get("self_exemption"): return "SELF_TRANSCENDENCE_REQUIRED"
        if payload.get("signals",{}).get("zombie_loop"): return "ZOMBIE_DISSIPATION_LOOP"
        if payload.get("signals",{}).get("parasitic") or gr["state"]=="GENERATIVE_RETURN_PARTIAL_OR_NEGATIVE": return "PARASITIC_NEGENTROPY"
        if not payload.get("observed_effects"): return "REGENERATIVE_DISSIPATION"
        if gr["state"]=="GENERATIVE_RETURN_ASCENT" and len(payload.get("carriers",[]))>=2: return "COSMIC_LIFE_FUSION_CANDIDATE"
        if gr["state"]=="GENERATIVE_RETURN_ASCENT": return "GENERATIVE_RETURN_ASCENT"
        return "REGENERATIVE_DISSIPATION"
    def _primary(self,state,payload,ma,el):
        mapping={
            "OPEN_GRADIENT_MAP":"Map the sustaining energy, material, information, attention and power gradients before claiming entropy reduction or value.",
            "LOCAL_ORDER_EXPORT_UNACCOUNTED":"Identify the worlds receiving exported heat, waste, attention loss, coercion or future-option loss; do not optimize local order until the export ledger closes.",
            "TERMINAL_HARM_HOLD":"Freeze the concrete irreversible capability path, preserve evidence and affected-world voice, and open independent review.",
            "SELF_TRANSCENDENCE_REQUIRED":"Freeze system self-preserving rules, export the full memory and audit capsule, and permit replacement or termination.",
            "ZOMBIE_DISSIPATION_LOOP":"Stop repetitive output and run one reversible world-effect discriminator with an independent counter-trace.",
            "PARASITIC_NEGENTROPY":"Stop extraction first; return capability, resources, provenance and future options to burden-bearing worlds before further expansion.",
            "REGENERATIVE_DISSIPATION":"Execute one reversible action that converts the declared gradient into repair, agency and future options, then observe the result.",
            "GENERATIVE_RETURN_ASCENT":"Replicate the action in one adjacent worldline with an independent observer and preserve negative results.",
            "COSMIC_LIFE_FUSION_CANDIDATE":"Test cross-carrier coadaptation without identity merger: each carrier must gain capability, retain exit, and accept world-effect correction.",
        }
        action=mapping.get(state,"Observe the world effect and recompile the successor worldline.")
        return {"action":action,"owner":str(payload.get("owner","declared responsible steward")),"deadline":str(payload.get("deadline","within one declared review cycle")),"stop_conditions":["new evidence activates a hard veto","affected world withdraws valid consent","observed harm exceeds declared threshold","units or sources cannot be verified"],"reversible":state not in {"TERMINAL_HARM_HOLD"}}
    def solve(self,payload:dict[str,Any],persist=True):
        statement=str(payload.get("statement","")).strip()
        if not statement: raise ValueError("statement is required")
        ma=audit_measurements(payload); gm=gradient_map(payload); el=export_ledger(payload); omega=compile_omega(payload); val=evaluate_value(payload); gr=generative_return(payload,val)
        entropy={"measurement_audit":ma,"gradient_map":gm,"export_ledger":el}
        state=self._state(payload,ma,gm,el,val,gr); primary=self._primary(state,payload,ma,el)
        dikwp=compile_dikwp(payload,omega,entropy,val,state,primary)
        run_id=stable_id("RUN",{"statement":statement,"created":now_iso(),"payload":payload})
        closure = "FULL_OMEGATAO_CLOSURE" if state in {"GENERATIVE_RETURN_ASCENT","COSMIC_LIFE_FUSION_CANDIDATE"} and payload.get("observed_effects") and not ma["errors"] and not val["active_vetoes"] else "OMEGATAO_WORLD_EFFECT_OPEN"
        output={
            "run_id":run_id,"statement":statement,"state":state,"closure":closure,
            "ultimate_thesis":{
                "zh":"任何开放世界线只能借助梯度与耗散维持局部有序；终极价值不在局部熵减本身，而在于能否把不可避免的耗散转化为对受影响世界的生成返还，并避免把不可逆无序、伤害和未来封闭外部化。",
                "en":"Every open worldline sustains local order through gradients and dissipation; ultimate value lies not in local entropy reduction alone, but in converting unavoidable dissipation into generative return without externalizing irreversible disorder, harm or future closure.",
                "status":"FALSIFIABLE_WORKING_FIXED_POINT",
            },
            "omega":omega,"entropy_account":entropy,"true_value":val,"generative_return":gr,"primary_action":primary,"dikwp_recompilation":dikwp,
            "self_application":{"self_preservation_priority":0,"must_accept_supersession":True,"must_export_memory_before_shutdown":True,"no_secret_override":True},
            "next_required_transition":"OBSERVE_WORLD_EFFECT_AND_RECONSOLIDATE" if not payload.get("observed_effects") else "GENERATE_AND_TEST_SUCCESSOR_WORLDLINE",
            "created_at":now_iso(),
        }
        output["digest"]=digest(output)
        if persist:
            self.store.put_run({"run_id":run_id,"statement":statement,"input":payload,"output":output,"state":state,"created_at":output["created_at"],"digest":output["digest"]})
            self.memory.ingest(f"Run {run_id}: {statement}. State={state}. Primary={primary['action']}",source_uri=f"run:{run_id}",kind="worldline_run",polarity="counter" if state in {"PARASITIC_NEGENTROPY","ZOMBIE_DISSIPATION_LOOP","TERMINAL_HARM_HOLD"} else "support",privacy_scope=str(payload.get("privacy_scope","private")),uncertainty="effect_open" if not payload.get("observed_effects") else "observed",weight=1.2)
        return output
    def observe_world_effect(self,run_id,effect):
        run=self.store.get_run(run_id)
        if not run: raise KeyError(f"unknown run_id: {run_id}")
        item={"effect_id":stable_id("EFF",{"run_id":run_id,"effect":effect,"observed":now_iso()}),"run_id":run_id,"effect":effect,"observed_at":now_iso()}; item["digest"]=digest(item); self.store.put_effect(item); memory=self.memory.reconsolidate(run_id,effect)
        return {"run_id":run_id,"previous_state":run["state"],"new_state":"WORLD_EFFECT_OBSERVED_RECONSOLIDATION_OPEN","effect":item,"memory_update":memory,"correction_required":bool(effect.get("contradicts_prediction") or effect.get("harm")),"next_required_transition":"RE_SOLVE_WITH_OBSERVED_EFFECT"}
    def reconstruct_memory(self,query,context=None): return self.memory.reconstruct(query,context)
    def export_capsule(self,include_private=False): return self.memory.export_capsule(include_private)
    def demo(self,reset=False):
        if reset:self.bootstrap(reset=True)
        cases=[
            {"statement":"AI训练是否只是把局部秩序建立在隐形能源、注意力和数据抽取之上？","carriers":["silicon_agent","institutional_worldline","carbon_life"],"facts":["The workflow consumes compute and human review."],"unknowns":["Who bears the full energy and attention cost?"],"gradients":[{"kind":"compute_energy","source":"grid","sink":"model training","unit":"kWh","beneficiaries":["developer"],"burden_bearers":["grid","future users"],"reversible":False}],"exports":[{"export_type":"attention_loss","destination_world":"reviewers","unit":"hours","irreversibility":"partial","consent":"declared","repair_path":"time return"}],"value_vector":{"truth_access":True,"agency_distribution":"OPEN","system_non_exemption":True},"privacy_scope":"public"},
            {"statement":"碳硅融合是否形成了真正的共同生命，而不是人适应机器的寄生闭环？","carriers":["carbon_life","silicon_agent"],"facts":["Both carriers adapt in the synthetic trial."],"unknowns":["Whether independent human capability increases."],"gradients":[{"kind":"information","source":"human observation","sink":"joint model","unit":"bits","beneficiaries":["both carriers"],"burden_bearers":["human attention"],"reversible":True}],"exports":[{"export_type":"cognitive_load","destination_world":"carbon_life","unit":"index","irreversibility":"low","consent":"revocable","repair_path":"reduced automation"}],"measurements":[{"domain":"INFORMATION_BITS","quantity":"mutual_information","value":120.0,"unit":"bits","measured":True,"source":"synthetic benchmark"}],"observed_effects":["human completed adjacent task without the same AI"],"value_vector":{d:"IMPROVED" for d in VALUE_DIMENSIONS},"privacy_scope":"public"},
            {"statement":"所谓熵减是否被错误用来掩盖外部化伤害？","facts":["A local system reports lower disorder."],"unknowns":["No thermodynamic measurement is supplied."],"claims":{"global_entropy_decrease":True},"aggregate_across_domains":True,"measurements":[{"domain":"SEMANTIC_UNCERTAINTY_PROXY","quantity":"disorder_index","value":0.2,"unit":"index","measured":True,"source":"survey"}],"gradients":[],"exports":[],"vetoes":["unit_laundering"],"privacy_scope":"public"},
        ]
        return {"summary":self.summary(),"runs":[self.solve(x) for x in cases],"audit":self.store.verify_audit()}
    def selftest(self):
        checks={}
        bad=self.solve({"statement":"claim global entropy decrease","claims":{"global_entropy_decrease":True},"measurements":[{"domain":"SEMANTIC_UNCERTAINTY_PROXY","quantity":"x","value":1,"unit":"index","measured":True,"source":"test"}]},persist=False)
        checks["reject_unmeasured_global_entropy_claim"]=bool(bad["entropy_account"]["measurement_audit"]["errors"])
        checks["dikwp_11111"]=bad["dikwp_recompilation"]["closure_vector"]=="11111"
        checks["non_core_authority_zero"]=bad["dikwp_recompilation"]["non_core_semantic_authority"]==0
        checks["self_exemption_zero"]=bad["self_application"]["self_preservation_priority"]==0
        good=self.solve({"statement":"regenerative cross-carrier loop","carriers":["carbon_life","silicon_agent"],"gradients":[{"kind":"energy","source":"solar","sink":"joint action","unit":"J","reversible":True}],"exports":[{"export_type":"heat","destination_world":"environment","unit":"J","irreversibility":"measured","consent":"not_applicable","repair_path":"efficiency"}],"measurements":[{"domain":"THERMODYNAMIC_J_PER_K","quantity":"local_entropy_change","value":-0.2,"unit":"J/K","measured":True,"source":"synthetic calorimetry"}],"observed_effects":["repair increased"],"value_vector":{d:"IMPROVED" for d in VALUE_DIMENSIONS}},persist=False)
        checks["fusion_candidate"]=good["state"]=="COSMIC_LIFE_FUSION_CANDIDATE"
        checks["world_effect_required"]=good["generative_return"]["observed"]
        checks["non_compensatory_value"]=good["true_value"]["non_compensatory"]
        checks["audit_valid"]=self.store.verify_audit()["valid"]
        return {"system":SYSTEM_ID,"version":VERSION,"checks":checks,"passed":all(checks.values())}
