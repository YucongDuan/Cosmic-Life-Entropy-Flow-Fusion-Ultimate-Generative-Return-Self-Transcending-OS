from __future__ import annotations
from typing import Any

def compile_dikwp(payload: dict[str, Any], omega: dict[str, Any], entropy: dict[str, Any], value: dict[str, Any], state: str, primary: dict[str, Any]) -> dict[str, Any]:
    d = {
        "sources": list(payload.get("facts", [])),
        "measurements": entropy["measurement_audit"]["measurements"],
        "carriers": list(payload.get("carriers", [])),
        "worldline_id": payload.get("worldline_id", "unassigned"),
    }
    i = {
        "unknowns": omega["unknowns"],
        "unit_errors": entropy["measurement_audit"]["errors"],
        "unaccounted_exports": entropy["export_ledger"]["unaccounted_count"],
        "counter_traces": list(payload.get("counter_traces", [])),
    }
    k = {
        "working_thesis": "Local order is sustained by gradients and dissipation; terminal value depends on generative return rather than local order alone.",
        "state": state,
        "limits": ["working system model", "not a physical proof of cosmic purpose", "not a person-worth classifier"],
    }
    w = {
        "value_vector": value["vector"],
        "hard_vetoes": value["active_vetoes"],
        "affected_worlds": value["affected_worlds"],
        "non_compensatory": True,
    }
    p = {
        "primary_action": primary,
        "process": ["sense gradients", "separate entropy domains", "map exports", "select reversible action", "observe effect", "reconsolidate memory", "generate successor"],
        "world_effect_required": True,
    }
    return {"D": d, "I": i, "K": k, "W": w, "P": p, "closure_vector": "11111", "semantic_authority": ["D", "I", "K", "W", "P"], "non_core_semantic_authority": 0}
