from __future__ import annotations
import json, sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from .canonical import canonical, digest, now_iso

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS source_records(record_id TEXT PRIMARY KEY, source_uri TEXT NOT NULL, content TEXT NOT NULL, kind TEXT NOT NULL, privacy_scope TEXT NOT NULL, created_at TEXT NOT NULL, digest TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS memory_traces(trace_id TEXT PRIMARY KEY, record_id TEXT, polarity TEXT NOT NULL, compressed TEXT NOT NULL, uncertainty TEXT NOT NULL, weight REAL NOT NULL, active INTEGER NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY, statement TEXT NOT NULL, input_json TEXT NOT NULL, output_json TEXT NOT NULL, state TEXT NOT NULL, created_at TEXT NOT NULL, digest TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS world_effects(effect_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, effect_json TEXT NOT NULL, observed_at TEXT NOT NULL, digest TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reconstructions(reconstruction_id TEXT PRIMARY KEY, query TEXT NOT NULL, output_json TEXT NOT NULL, created_at TEXT NOT NULL, digest TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_events(seq INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, object_id TEXT NOT NULL, payload_json TEXT NOT NULL, prev_hash TEXT NOT NULL, event_hash TEXT NOT NULL, created_at TEXT NOT NULL);
"""

class Store:
    def __init__(self, path: str|Path="var/omegatao87.db"):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as c: c.executescript(SCHEMA)
    @contextmanager
    def connect(self):
        c=sqlite3.connect(self.path); c.row_factory=sqlite3.Row
        try: yield c; c.commit()
        finally: c.close()
    def reset(self):
        if self.path.exists(): self.path.unlink()
        with self.connect() as c: c.executescript(SCHEMA)
    def audit(self, event_type, object_id, payload):
        created=now_iso()
        with self.connect() as c:
            r=c.execute("SELECT event_hash FROM audit_events ORDER BY seq DESC LIMIT 1").fetchone(); prev=r[0] if r else "GENESIS"
            body={"event_type":event_type,"object_id":object_id,"payload":payload,"prev_hash":prev,"created_at":created}; h=digest(body)
            c.execute("INSERT INTO audit_events(event_type,object_id,payload_json,prev_hash,event_hash,created_at) VALUES(?,?,?,?,?,?)",(event_type,object_id,canonical(payload),prev,h,created))
        return h
    def verify_audit(self):
        with self.connect() as c: rows=c.execute("SELECT * FROM audit_events ORDER BY seq").fetchall()
        prev="GENESIS"; errors=[]
        for r in rows:
            payload=json.loads(r["payload_json"]); body={"event_type":r["event_type"],"object_id":r["object_id"],"payload":payload,"prev_hash":r["prev_hash"],"created_at":r["created_at"]}
            if r["prev_hash"]!=prev: errors.append(f"seq {r['seq']} prev mismatch")
            if digest(body)!=r["event_hash"]: errors.append(f"seq {r['seq']} hash mismatch")
            prev=r["event_hash"]
        return {"valid":not errors,"event_count":len(rows),"head_hash":prev,"errors":errors}
    def put_source(self,item):
        with self.connect() as c: c.execute("INSERT OR REPLACE INTO source_records VALUES(?,?,?,?,?,?,?)",(item["record_id"],item["source_uri"],item["content"],item["kind"],item["privacy_scope"],item["created_at"],item["digest"]))
        self.audit("source.put",item["record_id"],{k:v for k,v in item.items() if k!="content"})
    def sources(self,limit=500):
        with self.connect() as c: rows=c.execute("SELECT * FROM source_records ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]
    def put_trace(self,item):
        with self.connect() as c: c.execute("INSERT OR REPLACE INTO memory_traces VALUES(?,?,?,?,?,?,?,?)",(item["trace_id"],item.get("record_id"),item["polarity"],item["compressed"],item["uncertainty"],float(item["weight"]),1 if item["active"] else 0,item["created_at"]))
        self.audit("trace.put",item["trace_id"],{k:v for k,v in item.items() if k!="compressed"})
    def traces(self,active_only=True,limit=500):
        sql="SELECT * FROM memory_traces"+(" WHERE active=1" if active_only else "")+" ORDER BY weight DESC, created_at DESC LIMIT ?"
        with self.connect() as c: rows=c.execute(sql,(limit,)).fetchall()
        return [{**dict(r),"active":bool(r["active"])} for r in rows]
    def put_run(self,item):
        with self.connect() as c: c.execute("INSERT OR REPLACE INTO runs VALUES(?,?,?,?,?,?,?)",(item["run_id"],item["statement"],canonical(item["input"]),canonical(item["output"]),item["state"],item["created_at"],item["digest"]))
        self.audit("run.put",item["run_id"],{"state":item["state"],"digest":item["digest"]})
    def get_run(self,run_id):
        with self.connect() as c: r=c.execute("SELECT * FROM runs WHERE run_id=?",(run_id,)).fetchone()
        if not r: return None
        d=dict(r); d["input"]=json.loads(d.pop("input_json")); d["output"]=json.loads(d.pop("output_json")); return d
    def list_runs(self,limit=100):
        with self.connect() as c: rows=c.execute("SELECT * FROM runs ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()
        out=[]
        for r in rows:
            d=dict(r); d["input"]=json.loads(d.pop("input_json")); d["output"]=json.loads(d.pop("output_json")); out.append(d)
        return out
    def put_effect(self,item):
        with self.connect() as c: c.execute("INSERT OR REPLACE INTO world_effects VALUES(?,?,?,?,?)",(item["effect_id"],item["run_id"],canonical(item["effect"]),item["observed_at"],item["digest"]))
        self.audit("effect.put",item["effect_id"],{"run_id":item["run_id"],"digest":item["digest"]})
    def effects(self,limit=500):
        with self.connect() as c: rows=c.execute("SELECT * FROM world_effects ORDER BY observed_at DESC LIMIT ?",(limit,)).fetchall()
        return [{"effect_id":r["effect_id"],"run_id":r["run_id"],"effect":json.loads(r["effect_json"]),"observed_at":r["observed_at"],"digest":r["digest"]} for r in rows]
    def put_reconstruction(self,item):
        with self.connect() as c: c.execute("INSERT OR REPLACE INTO reconstructions VALUES(?,?,?,?,?)",(item["reconstruction_id"],item["query"],canonical(item["output"]),item["created_at"],item["digest"]))
        self.audit("memory.reconstruct",item["reconstruction_id"],{"digest":item["digest"]})
