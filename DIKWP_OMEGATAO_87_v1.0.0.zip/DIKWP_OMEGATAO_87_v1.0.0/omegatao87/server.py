from __future__ import annotations
import json,mimetypes
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from http import HTTPStatus
from pathlib import Path
from urllib.parse import urlparse
from .engine import OmegaTaoEngine

class Handler(BaseHTTPRequestHandler):
    server_version="OmegaTao87/1.0"
    @property
    def engine(self): return self.server.engine
    def _json(self,status,payload):
        body=json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True).encode(); self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(body))); self.send_header("Cache-Control","no-store"); self.send_header("X-Content-Type-Options","nosniff"); self.send_header("X-Frame-Options","DENY"); self.send_header("Referrer-Policy","no-referrer"); self.end_headers(); self.wfile.write(body)
    def _read(self):
        n=int(self.headers.get("Content-Length","0"));
        if n>2_000_000: raise ValueError("request too large")
        x=json.loads((self.rfile.read(n) if n else b"{}").decode());
        if not isinstance(x,dict): raise ValueError("JSON object required")
        return x
    def _static(self,relative):
        root=self.server.root; rel=relative.lstrip("/") or "index.html"; p=(root/rel).resolve()
        if root.resolve() not in p.parents and p!=root.resolve(): self.send_error(403); return
        if not p.is_file(): self.send_error(404); return
        data=p.read_bytes(); ct=mimetypes.guess_type(p.name)[0] or "application/octet-stream"; self.send_response(200); self.send_header("Content-Type",ct+("; charset=utf-8" if ct.startswith("text/") or ct=="application/javascript" else "")); self.send_header("Content-Length",str(len(data))); self.send_header("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"); self.send_header("X-Content-Type-Options","nosniff"); self.send_header("X-Frame-Options","DENY"); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path).path
        try:
            if path=="/api/health": self._json(200,{"status":"ok","system":"DIKWP-OMEGATAO-87","version":"1.0.0"})
            elif path=="/api/summary": self._json(200,self.engine.summary())
            elif path=="/api/runs": self._json(200,self.engine.store.list_runs())
            elif path=="/api/audit": self._json(200,self.engine.store.verify_audit())
            elif path=="/api/capsule/public": self._json(200,self.engine.export_capsule(False))
            elif path.startswith("/api/run/"):
                x=self.engine.store.get_run(path.rsplit('/',1)[-1]); self._json(200 if x else 404,x or {"error":"not found"})
            else: self._static(path)
        except Exception as e: self._json(500,{"error":type(e).__name__,"detail":str(e)})
    def do_POST(self):
        path=urlparse(self.path).path
        try:
            data=self._read()
            if path=="/api/solve": self._json(201,self.engine.solve(data))
            elif path=="/api/world-effect": self._json(201,self.engine.observe_world_effect(str(data.pop("run_id","")),data))
            elif path=="/api/memory/reconstruct": self._json(201,self.engine.reconstruct_memory(str(data.get("query","")),data.get("context",{})))
            elif path=="/api/demo": self._json(201,self.engine.demo(bool(data.get("reset"))))
            else:self._json(404,{"error":"unknown endpoint"})
        except (ValueError,KeyError,json.JSONDecodeError) as e:self._json(400,{"error":type(e).__name__,"detail":str(e)})
        except Exception as e:self._json(500,{"error":type(e).__name__,"detail":str(e)})
    def log_message(self,*args): return

def serve(root,db_path,host,port):
    root=Path(root).resolve(); eng=OmegaTaoEngine(db_path); eng.bootstrap(); srv=ThreadingHTTPServer((host,port),Handler); srv.root=root; srv.engine=eng; print(f"OMEGATAO-87 listening on http://{host}:{port}"); srv.serve_forever()
