from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any

@dataclass(frozen=True)
class DomainMeasurement:
    domain: str
    quantity: str
    value: float | None
    unit: str
    measured: bool
    source: str
    scope: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
