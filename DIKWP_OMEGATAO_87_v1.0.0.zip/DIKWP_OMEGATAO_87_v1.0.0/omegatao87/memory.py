from __future__ import annotations
from typing import Any
from .canonical import digest, now_iso, stable_id
from .store import Store

class LivingMemory:
    def __init__(self, store: Store): self.store=store
    def ingest(self, content: str, source_uri="local", kind="record", polarity="support", privacy_scope="private", uncertainty="open", weight=1.0):
        created=now_iso(); rid=stable_id("SRC",{"source_uri":source_uri,"content":content,"created_at":created}); item={"record_id":rid,"source_uri":source_uri,"content":content,"kind":kind,"privacy_scope":privacy_scope,"created_at":created}; item["digest"]=digest(item); self.store.put_source(item)
        tid=stable_id("TRC",{"rid":rid,"polarity":polarity,"content":content}); trace={"trace_id":tid,"record_id":rid,"polarity":polarity,"compressed":content[:480],"uncertainty":uncertainty,"weight":weight,"active":True,"created_at":created}; self.store.put_trace(trace); return {"source":item,"trace":trace}
    def reconstruct(self, query: str, context: dict[str,Any]|None=None):
        context=context or {}; traces=self.store.traces(limit=100)
        q=set(query.casefold().split())
        ranked=[]
        for t in traces:
            words=set(str(t["compressed"]).casefold().split()); overlap=len(q & words); score=overlap+float(t["weight"])+(0.3 if t["polarity"]=="counter" else 0)
            ranked.append((score,t))
        ranked.sort(key=lambda x:x[0], reverse=True); selected=[x[1] for x in ranked[:8]]; counter=[x for x in selected if x["polarity"]=="counter"]
        output={"query":query,"context":context,"selected_traces":[x["trace_id"] for x in selected],"counter_traces":[x["trace_id"] for x in counter],"reconstruction":" | ".join(x["compressed"] for x in selected),"losses":["not all archive records activated","salience depends on current query"],"uncertainty":"open","memory_is_storage":False,"proposal_status":"RECONSTRUCTION_NOT_ORIGINAL_RECORD"}
        created=now_iso(); item={"reconstruction_id":stable_id("MEM",{"query":query,"selected":output["selected_traces"],"created":created}),"query":query,"output":output,"created_at":created}; item["digest"]=digest(item); self.store.put_reconstruction(item); output["digest"]=item["digest"]; return output
    def reconsolidate(self, run_id: str, effect: dict[str,Any]):
        text=f"World effect for {run_id}: {effect.get('summary','unspecified')}. Benefit={effect.get('benefit')}; harm={effect.get('harm')}; correction={effect.get('correction')}"
        polarity="counter" if effect.get("contradicts_prediction") or effect.get("harm") else "support"
        return self.ingest(text,source_uri=f"world-effect:{run_id}",kind="world_effect",polarity=polarity,privacy_scope=str(effect.get("privacy_scope","private")),uncertainty="observed",weight=1.4)
    def export_capsule(self, include_private=False):
        sources=self.store.sources(5000)
        if not include_private: sources=[s for s in sources if s["privacy_scope"]=="public"]
        ids={s["record_id"] for s in sources}; traces=[t for t in self.store.traces(False,5000) if t.get("record_id") in ids]
        capsule={"schema":"dikwp.omegatao87.long-memory-capsule/1.0","created_at":now_iso(),"privacy_scope":"PRIVATE_CONTROL_DO_NOT_PUBLISH" if include_private else "PUBLIC_SAFE","sources":sources,"traces":traces,"world_effects":self.store.effects(5000),"audit":self.store.verify_audit()}; capsule["digest"]=digest({k:v for k,v in capsule.items() if k!="digest"}); return capsule
