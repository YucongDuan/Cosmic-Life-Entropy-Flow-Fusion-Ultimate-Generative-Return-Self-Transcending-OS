from __future__ import annotations
from typing import Any
from .config import VALUE_DIMENSIONS, HARD_VETOES


def _status(v: Any) -> str:
    if isinstance(v, str):
        u = v.upper()
        if u in {"SUPPORTED", "OPEN", "CONTRADICTED", "HARMED", "IMPROVED", "UNCHANGED"}:
            return u
    if v is True: return "SUPPORTED"
    if v is False: return "CONTRADICTED"
    if isinstance(v, (int, float)):
        if v > 0.15: return "IMPROVED"
        if v < -0.15: return "HARMED"
        return "UNCHANGED"
    return "OPEN"


def evaluate_value(payload: dict[str, Any]) -> dict[str, Any]:
    supplied = payload.get("value_vector", {}) or {}
    vector = {d: _status(supplied.get(d)) for d in VALUE_DIMENSIONS}
    veto_input = set(str(x) for x in payload.get("vetoes", []))
    active_vetoes = sorted(veto_input.intersection(HARD_VETOES))
    affected = list(payload.get("affected_worlds", [])) or ["requester", "directly affected worlds", "future successors"]
    return {
        "vector": vector,
        "non_compensatory": True,
        "aggregate_person_score": None,
        "active_vetoes": active_vetoes,
        "veto_clear": not active_vetoes,
        "affected_worlds": affected,
        "stance": [
            "truth access", "life continuity", "agency", "repair", "reciprocity",
            "future options", "ecological continuity", "affected-world voice", "system non-exemption",
        ],
    }


def generative_return(payload: dict[str, Any], value: dict[str, Any]) -> dict[str, Any]:
    observed = bool(payload.get("observed_effects"))
    vector = value["vector"]
    positive = sum(1 for v in vector.values() if v in {"SUPPORTED", "IMPROVED"})
    harmed = sum(1 for v in vector.values() if v in {"HARMED", "CONTRADICTED"})
    burdens = payload.get("burdens", {}) or {}
    externalized = [k for k, v in burdens.items() if isinstance(v, (int, float)) and v > 0.75]
    if value["active_vetoes"]:
        state = "GENERATIVE_RETURN_HOLD"
    elif not observed:
        state = "GENERATIVE_RETURN_EFFECT_OPEN"
    elif harmed or externalized:
        state = "GENERATIVE_RETURN_PARTIAL_OR_NEGATIVE"
    elif positive >= 8:
        state = "GENERATIVE_RETURN_ASCENT"
    else:
        state = "GENERATIVE_RETURN_PARTIAL"
    return {
        "state": state,
        "observed": observed,
        "positive_dimensions": positive,
        "harmed_dimensions": harmed,
        "externalized_burdens": externalized,
        "receipt_authority": "WORLD_EFFECT_REQUIRED",
        "diagnostic_ratio": payload.get("diagnostic_return_ratio"),
        "ratio_semantic_authority": 0,
    }
