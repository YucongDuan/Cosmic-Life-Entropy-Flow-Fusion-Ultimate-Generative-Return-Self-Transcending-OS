from __future__ import annotations
from typing import Any
from .config import ENTROPY_DOMAINS

UNIT_RULES = {
    "THERMODYNAMIC_J_PER_K": {"J/K", "J K^-1", "joule_per_kelvin"},
    "INFORMATION_BITS": {"bit", "bits"},
    "SEMANTIC_UNCERTAINTY_PROXY": {"proxy", "dimensionless", "index"},
    "NORMATIVE_BURDEN_VECTOR": {"vector", "index", "declared_units"},
}


def _items(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw = payload.get("measurements", [])
    return [x for x in raw if isinstance(x, dict)]


def audit_measurements(payload: dict[str, Any]) -> dict[str, Any]:
    measurements = _items(payload)
    normalized: list[dict[str, Any]] = []
    errors: list[str] = []
    warnings: list[str] = []
    domains_seen: set[str] = set()
    for i, item in enumerate(measurements):
        domain = str(item.get("domain", "")).strip()
        unit = str(item.get("unit", "")).strip()
        quantity = str(item.get("quantity", "")).strip()
        measured = bool(item.get("measured", item.get("value") is not None))
        source = str(item.get("source", "undeclared"))
        value = item.get("value")
        if domain not in ENTROPY_DOMAINS:
            errors.append(f"measurement[{i}] unknown domain: {domain}")
            continue
        domains_seen.add(domain)
        if unit not in UNIT_RULES[domain]:
            errors.append(f"measurement[{i}] invalid unit '{unit}' for {domain}")
        if measured and value is None:
            errors.append(f"measurement[{i}] marked measured but has no value")
        if domain == "THERMODYNAMIC_J_PER_K" and measured and source == "unmeasured metaphor":
            errors.append("thermodynamic entropy cannot use an unmeasured metaphor as source")
        normalized.append({
            "domain": domain, "quantity": quantity, "value": value, "unit": unit,
            "measured": measured, "source": source, "scope": str(item.get("scope", "")),
        })
    claimed_global = bool(payload.get("claims", {}).get("global_entropy_decrease"))
    measured_thermo = any(x["domain"] == "THERMODYNAMIC_J_PER_K" and x["measured"] for x in normalized)
    if claimed_global and not measured_thermo:
        errors.append("global entropy decrease claim lacks thermodynamic measurement")
    if len(domains_seen) >= 2 and payload.get("aggregate_across_domains"):
        errors.append("unit laundering: entropy domains cannot be directly aggregated")
    if not measurements:
        warnings.append("no physical or informational measurements supplied; outputs remain structural")
    return {
        "domains": list(ENTROPY_DOMAINS),
        "measurements": normalized,
        "errors": errors,
        "warnings": warnings,
        "unit_isolation_pass": not errors,
        "physical_claim_authority": "MEASURED_ONLY" if measured_thermo else "STRUCTURAL_NO_PHYSICAL_QUANTIFICATION",
    }


def gradient_map(payload: dict[str, Any]) -> dict[str, Any]:
    gradients = []
    for item in payload.get("gradients", []):
        if not isinstance(item, dict):
            continue
        gradients.append({
            "kind": str(item.get("kind", "unknown")),
            "source": str(item.get("source", "unknown")),
            "sink": str(item.get("sink", "unknown")),
            "magnitude": item.get("magnitude"),
            "unit": str(item.get("unit", "undeclared")),
            "beneficiaries": list(item.get("beneficiaries", [])),
            "burden_bearers": list(item.get("burden_bearers", [])),
            "reversible": bool(item.get("reversible", False)),
        })
    return {
        "gradients": gradients,
        "open": not bool(gradients),
        "question": "Which energy, material, information, attention and power gradients sustain this worldline?",
    }


def export_ledger(payload: dict[str, Any]) -> dict[str, Any]:
    exports = []
    for item in payload.get("exports", []):
        if not isinstance(item, dict):
            continue
        exports.append({
            "export_type": str(item.get("export_type", "unclassified")),
            "destination_world": str(item.get("destination_world", "unidentified")),
            "magnitude": item.get("magnitude"),
            "unit": str(item.get("unit", "undeclared")),
            "irreversibility": str(item.get("irreversibility", "unknown")),
            "consent": str(item.get("consent", "unknown")),
            "repair_path": str(item.get("repair_path", "open")),
        })
    hidden = [x for x in exports if x["destination_world"] == "unidentified" or x["consent"] == "unknown"]
    return {
        "exports": exports,
        "unaccounted_count": len(hidden),
        "state": "EXPORT_ACCOUNTED" if exports and not hidden else "EXPORT_OPEN",
    }
