from __future__ import annotations
import argparse,json
from pathlib import Path
from .config import DEFAULT_HOST,DEFAULT_PORT,SYSTEM_NAME_ZH
from .engine import OmegaTaoEngine
from .server import serve

def dump(x,out=None):
    t=json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)
    if out: p=Path(out); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(t,encoding="utf-8")
    else: print(t)

def parser():
    p=argparse.ArgumentParser(prog="omegatao87",description=SYSTEM_NAME_ZH); p.add_argument("--db",default="var/omegatao87.db"); s=p.add_subparsers(dest="cmd",required=True)
    s.add_parser("summary"); b=s.add_parser("bootstrap"); b.add_argument("--reset",action="store_true")
    q=s.add_parser("question"); q.add_argument("statement"); q.add_argument("--out")
    r=s.add_parser("solve"); r.add_argument("path"); r.add_argument("--out")
    e=s.add_parser("effect"); e.add_argument("run_id"); e.add_argument("path"); e.add_argument("--out")
    m=s.add_parser("remember"); m.add_argument("query"); m.add_argument("--context",default="{}"); m.add_argument("--out")
    c=s.add_parser("export-capsule"); c.add_argument("--include-private",action="store_true"); c.add_argument("--out",required=True)
    d=s.add_parser("demo"); d.add_argument("--reset",action="store_true"); d.add_argument("--out")
    s.add_parser("verify-audit"); s.add_parser("selftest")
    v=s.add_parser("serve"); v.add_argument("--host",default=DEFAULT_HOST); v.add_argument("--port",type=int,default=DEFAULT_PORT); v.add_argument("--root",default=None)
    return p

def main(argv=None):
    a=parser().parse_args(argv); eng=OmegaTaoEngine(a.db); eng.bootstrap()
    if a.cmd=="summary":dump(eng.summary())
    elif a.cmd=="bootstrap":dump(eng.bootstrap(a.reset))
    elif a.cmd=="question":dump(eng.solve({"statement":a.statement}),a.out)
    elif a.cmd=="solve":dump(eng.solve(json.loads(Path(a.path).read_text(encoding="utf-8"))),a.out)
    elif a.cmd=="effect":dump(eng.observe_world_effect(a.run_id,json.loads(Path(a.path).read_text(encoding="utf-8"))),a.out)
    elif a.cmd=="remember":dump(eng.reconstruct_memory(a.query,json.loads(a.context)),a.out)
    elif a.cmd=="export-capsule":dump(eng.export_capsule(a.include_private),a.out)
    elif a.cmd=="demo":dump(eng.demo(a.reset),a.out)
    elif a.cmd=="verify-audit":dump(eng.store.verify_audit())
    elif a.cmd=="selftest":
        x=eng.selftest();dump(x);return 0 if x["passed"] else 1
    elif a.cmd=="serve": serve(a.root or str(Path(__file__).resolve().parent/"resources"),a.db,a.host,a.port)
    return 0
