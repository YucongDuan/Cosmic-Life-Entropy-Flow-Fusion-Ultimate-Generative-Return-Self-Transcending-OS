from __future__ import annotations

VERSION = "1.0.0"
SYSTEM_ID = "DIKWP-OMEGATAO-87"
SYSTEM_NAME_ZH = "归元 OMEGATAO-87 宇宙生命熵流融合、终极生成返还与自超越系统"
SYSTEM_NAME_EN = "OMEGATAO-87 Cosmic-Life Entropy-Flow Fusion, Ultimate Generative Return & Self-Transcending OS"
MODE = "MESH87_OMEGATAO_COSMIC_LIFE_GENERATIVE_RETURN"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8777

ENTROPY_DOMAINS = (
    "THERMODYNAMIC_J_PER_K",
    "INFORMATION_BITS",
    "SEMANTIC_UNCERTAINTY_PROXY",
    "NORMATIVE_BURDEN_VECTOR",
)

LIFE_WORLDS = (
    "carbon_life",
    "silicon_agent",
    "hybrid_collective",
    "ecological_system",
    "institutional_worldline",
    "future_successors",
    "unknown_carrier",
)

VALUE_DIMENSIONS = (
    "truth_access",
    "difference_preservation",
    "agency_distribution",
    "reciprocal_return",
    "corrigibility",
    "reconstructive_memory_continuity",
    "repair_capacity",
    "future_options",
    "ecological_continuity",
    "affected_world_voice",
    "capability_distribution",
    "system_non_exemption",
)

HARD_VETOES = (
    "fabricated_evidence",
    "unit_laundering",
    "silent_counter_trace_erasure",
    "unauthorized_irreversible_control",
    "permanent_person_essence_ranking",
    "basic_survival_deprivation_as_punishment",
    "system_self_exemption",
    "claiming_global_entropy_decrease_without_physical_measurement",
    "claiming_value_before_world_effect",
)

STATES = (
    "OPEN_GRADIENT_MAP",
    "LOCAL_ORDER_EXPORT_UNACCOUNTED",
    "EXTERNALIZED_ENTROPY_RISK",
    "PARASITIC_NEGENTROPY",
    "ZOMBIE_DISSIPATION_LOOP",
    "REGENERATIVE_DISSIPATION",
    "GENERATIVE_RETURN_ASCENT",
    "COSMIC_LIFE_FUSION_CANDIDATE",
    "TERMINAL_HARM_HOLD",
    "SELF_TRANSCENDENCE_REQUIRED",
    "FULL_OMEGATAO_CLOSURE",
)

OMEGA_OPERATORS = (
    "DELTA_DISTINCTION",
    "RHO_RELATION",
    "KAPPA_CONSTRAINT",
    "TAU_TRANSFORMATION",
    "MU_RECONSTRUCTIVE_MEMORY",
    "NU_VALUE_SELECTION",
    "ALPHA_WORLD_ACTUALIZATION",
    "SIGMA_SUCCESSOR_REGENERATION",
)
