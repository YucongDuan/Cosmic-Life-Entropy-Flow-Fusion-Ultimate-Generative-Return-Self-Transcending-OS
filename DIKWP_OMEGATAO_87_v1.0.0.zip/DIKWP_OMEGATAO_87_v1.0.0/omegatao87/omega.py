from __future__ import annotations
import re
from typing import Any
from .config import OMEGA_OPERATORS

ALIASES = {
    "人": "bounded memory-value-action worldline",
    "human": "bounded memory-value-action worldline",
    "生命": "gradient-coupled, reconstructive, repairing and successor-generating worldline",
    "life": "gradient-coupled, reconstructive, repairing and successor-generating worldline",
    "天道": "candidate invariant of generative return under irreversible dissipation",
    "tao": "candidate invariant of generative return under irreversible dissipation",
    "熵减": "local order generation with explicit entropy export and unit separation",
    "negentropy": "local order generation with explicit entropy export and unit separation",
    "宇宙": "multi-scale relation and constraint field containing declared observers and worldlines",
    "universe": "multi-scale relation and constraint field containing declared observers and worldlines",
    "意识": "integrated reconstruction that can alter value, model and action",
    "consciousness": "integrated reconstruction that can alter value, model and action",
    "终极": "fixed-point candidate that remains self-applicable and world-correctable",
    "ultimate": "fixed-point candidate that remains self-applicable and world-correctable",
}

def uniq(xs, limit=80):
    out=[]; seen=set()
    for x in xs:
        s=str(x).strip(); k=s.casefold()
        if s and k not in seen: seen.add(k); out.append(s)
        if len(out)>=limit: break
    return out

def concepts(statement: str, explicit=None):
    out=list(explicit or [])
    lo=statement.casefold()
    for k in ALIASES:
        if k.casefold() in lo: out.append(k)
    out += re.findall(r"[“\"']([^”\"']{1,40})[”\"']", statement)
    return uniq(out, 32)

def deconstruct(items):
    return [{
        "alias": c,
        "successor": ALIASES.get(c.casefold(), ALIASES.get(c, "relation-bounded worldline with source, scope, memory, value and world effect")),
        "questions": [
            f"Which distinctions make '{c}' observable?",
            f"Which gradients and exports sustain '{c}'?",
            f"Which affected worlds are absent from '{c}'?",
            f"Which world effect would force a successor concept?",
        ],
    } for c in items]

def compile_omega(payload: dict[str, Any]) -> dict[str, Any]:
    statement=str(payload.get("statement", "")).strip()
    if not statement: raise ValueError("statement is required")
    facts=uniq(payload.get("facts", [])); unknowns=uniq(payload.get("unknowns", []))
    affected=uniq(payload.get("affected_worlds", [])) or ["requester", "directly affected worlds", "future successors"]
    cs=concepts(statement, payload.get("concepts", []))
    distinctions=uniq(unknowns + [f"claim versus observed world effect: {statement}"])
    relations=uniq(payload.get("relations", []) + ["gradient → dissipation → local order → export → affected world → return or debt"])
    constraints=uniq(payload.get("constraints", [])) or [
        "the second law cannot be overwritten by metaphor",
        "entropy domains cannot be aggregated without a declared conversion model",
        "facts, consent and real authority cannot be fabricated by language",
        "system self-preservation has no exemption",
    ]
    transformations=uniq(payload.get("candidate_transformations", [])) or [
        "measure the sustaining gradients and exported burdens",
        "construct a reversible action that increases generative return",
        "observe the world effect and reconsolidate memory",
    ]
    memory=uniq(payload.get("memory_records", [])) or ["source archive", "counter-trace", "world-effect record", "successor rule"]
    values=uniq(payload.get("values", [])) or ["truth access", "agency", "repair", "reciprocity", "future options"]
    effects=uniq(payload.get("observed_effects", [])) or ["world effect not yet observed"]
    successors=uniq(payload.get("desired_successors", [])) or ["a worldline with higher generative return", "a falsifiable successor rule"]
    return {
        "operators": list(OMEGA_OPERATORS),
        "concepts": deconstruct(cs),
        "DELTA_DISTINCTION": distinctions,
        "RHO_RELATION": relations,
        "KAPPA_CONSTRAINT": constraints,
        "TAU_TRANSFORMATION": transformations,
        "MU_RECONSTRUCTIVE_MEMORY": memory,
        "NU_VALUE_SELECTION": values,
        "ALPHA_WORLD_ACTUALIZATION": effects,
        "SIGMA_SUCCESSOR_REGENERATION": successors,
        "affected_worlds": affected,
        "facts": facts,
        "unknowns": unknowns,
        "epistemic_status": "PRECONCEPTUAL_WORKING_SPACE",
    }
