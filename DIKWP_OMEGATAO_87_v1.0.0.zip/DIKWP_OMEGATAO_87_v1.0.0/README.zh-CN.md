# 归元 OMEGATAO-87

**宇宙生命熵流融合、终极生成返还与自超越系统**

系统把MESH8.7活性长忆、GENESIS-Ω前概念算子、碳硅共生、终极价值和现实世界效果连接起来。它不把局部有序或“熵减”自动等同于善，而是追问：维持该秩序的梯度来自哪里，熵与负担被输出到哪里，受影响世界是否获得生成返还。

```bash
python run.py summary
python run.py demo --reset
python start_showcase.py
```

访问 `http://127.0.0.1:8777`。
