from omegatao87.cli import main
raise SystemExit(main())
