@echo off
cd /d %~dp0
py -3 start_showcase.py || python start_showcase.py
pause
