import json,tempfile,threading,urllib.request,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from http.server import ThreadingHTTPServer
from omegatao87.server import Handler
from omegatao87.engine import OmegaTaoEngine
root=Path(__file__).resolve().parents[1]; t=tempfile.TemporaryDirectory(); s=ThreadingHTTPServer(('127.0.0.1',0),Handler); s.root=root/'omegatao87/resources'; s.engine=OmegaTaoEngine(t.name+'/x.db'); s.engine.bootstrap(); th=threading.Thread(target=s.serve_forever,daemon=True); th.start(); base=f'http://127.0.0.1:{s.server_address[1]}'; checks=[]
def get(p):
    with urllib.request.urlopen(base+p) as r:return r.status,r.read(),dict(r.headers)
def post(p,x):
    q=urllib.request.Request(base+p,data=json.dumps(x).encode(),headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(q) as r:return r.status,json.loads(r.read())
checks.append(('health',get('/api/health')[0]==200)); checks.append(('index',b'OMEGATAO' in get('/')[1])); checks.append(('summary',json.loads(get('/api/summary')[1])['version']=='1.0.0')); checks.append(('solve',post('/api/solve',{'statement':'test'})[0]==201)); checks.append(('audit',json.loads(get('/api/audit')[1])['valid'])); checks.append(('csp','default-src' in get('/')[2].get('Content-Security-Policy',''))); checks.append(('capsule',json.loads(get('/api/capsule/public')[1])['digest'] is not None)); s.shutdown(); t.cleanup(); out={'passed':all(v for _,v in checks),'checks':dict(checks)}; (root/'validation/http_acceptance.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(out,ensure_ascii=False)); raise SystemExit(0 if out['passed'] else 1)
