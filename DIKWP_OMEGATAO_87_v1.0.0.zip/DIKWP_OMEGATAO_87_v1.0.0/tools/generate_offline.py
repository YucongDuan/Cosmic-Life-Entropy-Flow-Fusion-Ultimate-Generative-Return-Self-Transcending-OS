from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'omegatao87/resources/index.html').read_text(encoding='utf-8')
css=(root/'omegatao87/resources/assets/styles.css').read_text(encoding='utf-8')
js=(root/'omegatao87/resources/assets/app.js').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="assets/styles.css">',f'<style>{css}</style>')
html=html.replace('<script src="assets/app.js"></script>',f'<script>{js}</script>')
out=root/'归元_OMEGATAO87_离线展示_双击打开_v1.0.0.html'
out.write_text(html,encoding='utf-8')
print(out)
