from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]; findings=[]; required=['README.md','LICENSE','openapi.json','omegatao87/engine.py','omegatao87/resources/index.html','OMEGATAO87_终极生成返还宪章_v1.0.0.md']
for x in required:
    if not (root/x).exists(): findings.append('missing:'+x)
for p in root.rglob('*'):
    if p.resolve()==Path(__file__).resolve() or 'validation' in p.parts:
        continue
    if p.is_file() and p.suffix in {'.py','.js','.html','.md','.json'}:
        t=p.read_text(encoding='utf-8',errors='ignore')
        for pat in ['neutrality_claimed=true','humanity_score =','automatic_external_action = true','eval\\(','subprocess\\.Popen','os\\.system']:
            if re.search(pat,t): findings.append(f'{p.relative_to(root)}:{pat}')
out={'passed':not findings,'files':sum(1 for p in root.rglob('*') if p.is_file()),'findings':findings}; (root/'validation/static_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(out,ensure_ascii=False)); raise SystemExit(0 if out['passed'] else 1)
