from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]; lines=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.sha256' and not any(x in p.parts for x in ('var','__pycache__')) and p.suffix!='.pyc': lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}")
(root/'MANIFEST.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8'); print(len(lines))
