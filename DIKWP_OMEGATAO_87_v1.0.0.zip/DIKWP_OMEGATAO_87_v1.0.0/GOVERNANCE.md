# Governance

Rules are versioned and challengeable. Changes to protected invariants require public rationale, affected-world review, tests, rollback and a new constitution digest. Forks may change rules but must not claim OMEGATAO-87 conformance if the invariant digest differs.
