# Contributing

Contributions must include sources, units, affected worlds, a falsifier, a reversible test and negative results. Do not add person-worth scores or conflate thermodynamic, informational and normative entropy.
