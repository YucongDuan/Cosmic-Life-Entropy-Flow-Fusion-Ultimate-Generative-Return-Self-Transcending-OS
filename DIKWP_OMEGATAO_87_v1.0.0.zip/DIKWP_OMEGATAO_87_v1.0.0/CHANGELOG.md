# Changelog

## 1.0.0
- Initial OMEGATAO-87 release.
- Four entropy-domain isolation.
- Gradient/export ledger, generative-return vector, living memory, self-transcendence and offline dashboard.
