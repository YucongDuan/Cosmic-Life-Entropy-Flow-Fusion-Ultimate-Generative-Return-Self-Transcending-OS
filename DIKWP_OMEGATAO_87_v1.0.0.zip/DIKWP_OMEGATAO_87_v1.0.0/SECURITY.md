# Security

Report vulnerabilities privately. The reference runtime binds to localhost, has no external model client, no credentials, no shell execution and no physical-control adapter. Request bodies are limited to 2 MB.
