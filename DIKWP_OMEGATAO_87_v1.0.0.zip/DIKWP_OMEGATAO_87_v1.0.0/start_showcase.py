from pathlib import Path
from omegatao87.server import serve
from omegatao87.config import DEFAULT_HOST,DEFAULT_PORT
if __name__=="__main__": serve(Path(__file__).resolve().parent/"omegatao87"/"resources","var/omegatao87.db",DEFAULT_HOST,DEFAULT_PORT)
