import json,tempfile,threading,unittest,urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from omegatao87.server import Handler
from omegatao87.engine import OmegaTaoEngine
class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t=tempfile.TemporaryDirectory(); root=Path(__file__).resolve().parents[1]/"omegatao87"/"resources"; cls.s=ThreadingHTTPServer(("127.0.0.1",0),Handler); cls.s.root=root; cls.s.engine=OmegaTaoEngine(cls.t.name+"/x.db"); cls.s.engine.bootstrap(); cls.th=threading.Thread(target=cls.s.serve_forever,daemon=True); cls.th.start(); cls.base=f"http://127.0.0.1:{cls.s.server_address[1]}"
    @classmethod
    def tearDownClass(cls): cls.s.shutdown(); cls.t.cleanup()
    def get(self,p):
        with urllib.request.urlopen(self.base+p) as r:return r.status,r.read(),dict(r.headers)
    def post(self,p,x):
        req=urllib.request.Request(self.base+p,data=json.dumps(x).encode(),headers={"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req) as r:return r.status,json.loads(r.read())
    def test_health(self): self.assertEqual(self.get('/api/health')[0],200)
    def test_index(self): self.assertIn(b'OMEGATAO',self.get('/')[1])
    def test_summary(self): self.assertEqual(json.loads(self.get('/api/summary')[1])["version"],"1.0.0")
    def test_solve(self): self.assertEqual(self.post('/api/solve',{"statement":"test"})[0],201)
    def test_headers(self): self.assertEqual(self.get('/')[2].get('X-Frame-Options'),'DENY')
if __name__=='__main__': unittest.main()
