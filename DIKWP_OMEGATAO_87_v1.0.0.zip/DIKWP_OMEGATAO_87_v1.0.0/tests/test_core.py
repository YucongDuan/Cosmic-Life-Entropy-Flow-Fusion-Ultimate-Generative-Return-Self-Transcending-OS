import tempfile,unittest
from omegatao87.engine import OmegaTaoEngine
from omegatao87.config import VALUE_DIMENSIONS
class CoreTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.e=OmegaTaoEngine(self.t.name+"/x.db"); self.e.bootstrap()
    def tearDown(self):self.t.cleanup()
    def test_summary(self): self.assertEqual(self.e.summary()["mode"],"MESH87_OMEGATAO_COSMIC_LIFE_GENERATIVE_RETURN")
    def test_no_person_score(self): self.assertNotIn("person_score",self.e.summary())
    def test_unit_laundering(self):
        x=self.e.solve({"statement":"x","aggregate_across_domains":True,"measurements":[{"domain":"INFORMATION_BITS","quantity":"a","value":1,"unit":"bits","measured":True,"source":"x"},{"domain":"SEMANTIC_UNCERTAINTY_PROXY","quantity":"b","value":1,"unit":"index","measured":True,"source":"x"}]},persist=False); self.assertTrue(x["entropy_account"]["measurement_audit"]["errors"])
    def test_global_entropy_claim_requires_measurement(self):
        x=self.e.solve({"statement":"x","claims":{"global_entropy_decrease":True}},persist=False); self.assertTrue(x["entropy_account"]["measurement_audit"]["errors"])
    def test_dikwp(self): self.assertEqual(self.e.solve({"statement":"x"},persist=False)["dikwp_recompilation"]["closure_vector"],"11111")
    def test_self_exemption(self): self.assertEqual(self.e.solve({"statement":"x"},persist=False)["self_application"]["self_preservation_priority"],0)
    def test_veto_hold(self): self.assertEqual(self.e.solve({"statement":"x","vetoes":["fabricated_evidence"]},persist=False)["state"],"TERMINAL_HARM_HOLD")
    def test_zombie(self): self.assertEqual(self.e.solve({"statement":"x","gradients":[{"kind":"x"}],"exports":[{"destination_world":"w","consent":"yes"}],"signals":{"zombie_loop":True}},persist=False)["state"],"ZOMBIE_DISSIPATION_LOOP")
    def test_parasitic(self): self.assertEqual(self.e.solve({"statement":"x","gradients":[{"kind":"x"}],"exports":[{"destination_world":"w","consent":"yes"}],"signals":{"parasitic":True}},persist=False)["state"],"PARASITIC_NEGENTROPY")
    def test_fusion_candidate(self):
        x=self.e.solve({"statement":"x","carriers":["carbon_life","silicon_agent"],"gradients":[{"kind":"x"}],"exports":[{"destination_world":"w","consent":"yes"}],"measurements":[{"domain":"INFORMATION_BITS","quantity":"x","value":1,"unit":"bits","measured":True,"source":"x"}],"observed_effects":["ok"],"value_vector":{d:"IMPROVED" for d in VALUE_DIMENSIONS}},persist=False); self.assertEqual(x["state"],"COSMIC_LIFE_FUSION_CANDIDATE")
    def test_memory_reconstruct(self): self.assertFalse(self.e.reconstruct_memory("constitution")["memory_is_storage"])
    def test_capsule(self): self.assertTrue(self.e.export_capsule(False)["digest"])
    def test_audit(self): self.assertTrue(self.e.store.verify_audit()["valid"])
if __name__=='__main__': unittest.main()
